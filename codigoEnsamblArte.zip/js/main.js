import clickOnSlider from "./clickOnSlider.js";

const d = document;



d.addEventListener("DOMContentLoaded", () => {
    clickOnSlider(".container-slider")

})